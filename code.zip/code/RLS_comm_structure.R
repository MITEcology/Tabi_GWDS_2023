rm(list=ls())

library(dplyr)

# load data
df0 <- read.csv("~/all_data.csv")  

# filter for RLS data 
df <- df0 %>% filter(program=="RLS")

# add year and ID
df$year <-  as.numeric(format(as.Date(df$survey_date), format = "%Y"))
df$ID <- paste(df$site_code, "_", df$year, sep="")

# remove biomass NAs
df1 <- df %>% filter(!is.na(biomass))

# add sampling effort (SE)
se <- df1 %>% dplyr::select(ID, survey_date) %>% group_by(ID) %>% unique %>% count()  
se$sampling_effort <- se$n
se$n <- NULL
df2 <- merge(df1, se, by=c("ID"), all.x=T )

# add number of species 
sr <- df2 %>% dplyr::select(ID, species_name) %>% group_by(ID) %>% unique() %>% count()
df3 <- merge(df2, sr, by="ID", all.x = T)
df3$SR <- df3$n
df3$n <- NULL

# filter data for SR > 4 & only SE > 1
df4 <-  df3 %>% filter(SR>4 & sampling_effort>1)   

# number of sites
sites <- length(unique(df4$site_code))
species <- length(unique(df4$species_name))

# number of data points
id <- sort(unique(df4$ID))

#########################################################################################
res <- data.frame()
for(i in 1:length(id)){

      data <- df3[df3$ID %in% id[i],]
      sp <- unique(data$species_name)
      site <- unique(data$site_code)
      se <- unique(data$sampling_effort)
      
      S <- list()
      for(j in 1:length(sp) ){
        temp <- data %>% dplyr::filter(species_name == as.character(sp[j]) ) %>% dplyr::select(species_name, biomass, total ) 
        temp <- na.omit(temp)
        S[[ sp[j] ]] <- rep((temp$biomass / temp$total), temp$total) 
      }

      res[ i, "site_code"] <- site
      res[ i, "year"] <- unique(data$year)
      res[ i, "ID"] <- id[i]
      res[ i, "latitude"] <- unique(data$lat)
      res[ i, "longitude"] <- unique(data$long)
      res[ i, "site_name"] <- unique(data$site_name )
      res[ i, "ecoregion"] <- unique(data$ecoregion )
      res[ i, "realm"] <- unique(data$realm)
      res[ i, "area"] <- unique(data$area)
      res[ i, "sr"] <- length(sp)
      res[ i, "sampling_effort"] <- se
      
      # Spearman's correlations
      AB_local <- unlist(lapply( S, length)) # abundance 
      BS_local <- unlist(lapply( S, mean)) # body size 
      BM_local <- unlist(lapply( S, sum)) # biomass 
      
      res[ i, "rho_bs_ab"] <- cor.test(log(AB_local), log(BS_local), method="spearman", exact=F)$est
      res[ i, "rho_bs_bm"] <- cor.test(log(BM_local), log(BS_local), method="spearman", exact=F)$est
      res[ i, "rho_bs_ab_pvalue"] <- cor.test(log(AB_local), log(BS_local), method="spearman", exact=F)$p.value
      res[ i, "rho_bs_bm_pvalue"] <- cor.test(log(BM_local), log(BS_local), method="spearman", exact=F)$p.value
      
      res[i, "Reg_BS_AB_pvalue"] <- summary(lm(log(AB_local) ~ log(BS_local)))$coef[2,4] 
      res[i, "Reg_BS_BM_pvalue"] <- summary(lm(log(BM_local) ~ log(BS_local)))$coef[2,4] 
      res[i, "Reg_BS_AB_coef"] <- summary(lm(log(AB_local) ~ log(BS_local)))$coef[2,1] 
      res[i, "Reg_BS_BM_coef"] <- summary(lm(log(BM_local) ~ log(BS_local)))$coef[2,1] 

      print(paste0("#", i, ", site = ", id[i])) 

}

# create database #######################################################################

load("~/Covariates.RData")

db <- dplyr::left_join(res, COV, by = c("site_code", "longitude", "latitude") )

# add variable IUCN cat Ia binary
db$MPA <- ifelse(db$year > db$STATUS_YR | is.na(db$STATUS_YR) , db$IsProtected, 0)
iucn <- ifelse( db$IUCN_CAT=="Ia"  , 1, 0 )
db$IUCN_Ia <- ifelse(db$year > db$STATUS_YR | is.na(db$STATUS_YR) , iucn, 0)

# save data
save(db, file="~/data.RData")



