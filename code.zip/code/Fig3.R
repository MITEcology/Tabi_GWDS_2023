rm(list=ls())

library(dplyr)
library(ggplot2) 
library(ggpattern)

#####################
load('~/data.RData')  

r <- as.numeric(db$Reg_BS_BM_coef)
se <- as.numeric(db$sampling_effort)
sst<- as.numeric(db$SumTSAfull)
st<- as.numeric(db$HumanPopDensity)
pro <- as.numeric(db$IUCN_Ia)
below <- as.numeric(db$Buffer10Km)

########### cut-off for sampling effort
t <- 1
########## transform continuous to binary variables using median
########## and filter by sampling effort
br <- r[se>t]
br[r[se>t]>median(r[se>t],na.rm=T)] <- 1
br[r[se>t]<=median(r[se>t],na.rm=T)] <- 0

bst <- st[se>t]
bst[st[se>t]>median(st[se>t],na.rm=T)] <- 1
bst[st[se>t]<=median(st[se>t],na.rm=T)] <- 0

bsst <- sst[se>t]
bsst[sst[se>t]>median(sst[se>t],na.rm=T)] <- 1
bsst[sst[se>t]<=median(sst[se>t],na.rm=T)] <- 0

bbelow <- below[se>t]
bbelow[below[se>t]>median(below[se>t],na.rm=T)] <- 1
bbelow[below[se>t]<=median(below[se>t],na.rm=T)] <- 0

bpro <- pro[se>t]

df <- cbind.data.frame( k=db$Reg_BS_BM_coef-1, 
                        mpa = ifelse(bpro==0, "Harvested", "Protected"),
                        coral = ifelse(bbelow==0, "Rocky reef", "Coral reef"),
                        human = ifelse(bst==0, "Low human density", "High human density"),
                        tsa = ifelse(bsst==0, "Low TSA", "High TSA") )

head(df)

plotA <- ggplot(df) + 
  geom_violin( aes(y=k , x=mpa, fill=mpa),  color="white"  ) + 
  ggtitle("")+
  geom_boxplot( aes(y=k , x=mpa ), outlier.shape=1, width=0.2 ) +
  xlab("")+ ylab(expression(paste("Structure (", k[c]^e, ")")) )+
  scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
  theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_hline(yintercept=median(df$k), linetype="dashed", color="gray40", size=1 )+
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=18),
        strip.text = element_text(size = 20), 
        strip.background = element_rect(fill="white", color="white"))

plotA

plotB <- ggplot(df) + 
  facet_wrap(~coral, nrow=1)+
  geom_violin( aes(y=k , x=mpa, fill=mpa),  color="white"  ) +
  geom_boxplot( aes(y=k , x=mpa ), outlier.shape = 1, width=0.2 ) +
  xlab("")+ ylab(expression(paste("Structure (", k[c]^e, ")")) )+
  theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_hline(yintercept=median(df$k), linetype="dashed", color="gray40", size=1 )+
  scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=18),
        strip.text = element_text(size = 20), 
        strip.background = element_rect(fill="white", color="white"))
plotB

plotC <- ggplot(df, aes(y=k , x=coral, fill=coral)) + 
        geom_violin( color="white" ) +
        ggtitle("")+
        geom_boxplot( aes(y=k , x=coral ), outlier.shape=1, fill="white",  width=0.2 ) +
        xlab("")+ ylab("")+
        scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
        theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
        geom_hline(yintercept=median(df$k), linetype="dashed", color="gray40", size=1 )+
        theme(legend.position = "none", axis.title = element_text(size=20),
              axis.text.x = element_text(size=20), axis.text.y = element_text(size=18),
              strip.text = element_text(size = 20), 
              strip.background = element_rect(fill="white", color="white"))

plotC


plotD <- ggplot(df %>% dplyr::select(k, mpa, tsa) %>% na.omit, aes(y=k , x=mpa, fill=mpa)) + 
  facet_wrap(~tsa, nrow=1)+
  geom_violin( color="white" ) +
  geom_boxplot( aes(y=k , x=mpa ), outlier.shape=1, fill="white",  width=0.2 ) +
  xlab("")+ ylab(expression(paste("Structure (", k[c]^e, ")")) )+
  theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_hline(yintercept=median(df$k), linetype="dashed", color="gray40", size=1 )+
  scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=18),
        strip.text = element_text(size = 20), 
        strip.background = element_rect(fill="white", color="white"))

plotD

plotE <- ggplot(df %>% dplyr::select(k, mpa, human) %>% na.omit, aes(y=k , x=mpa, fill=mpa)) + 
  facet_wrap(~human, nrow=1)+
  geom_violin(color="white" ) +
  geom_boxplot( aes(y=k , x=mpa ), outlier.shape=1,  fill="white",  width=0.2 ) +
  xlab("")+ ylab(expression(paste("Structure (", k[c]^e, ")")) )+
  theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_hline(yintercept=median(df$k), linetype="dashed", color="gray40", size=1 )+
  scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=18),
        strip.text = element_text(size = 20), 
        strip.background = element_rect(fill="white", color="white"))

plotE


library(ggpubr)
ggarrange(plotA, plotB, plotC, plotD, ncol = 2, nrow = 3,
          widths = c(3, 9),
          font.label = list(size = 22),
          align = "hv",
          labels = "AUTO")

plot1 <- ggarrange(plotA, plotC,  ncol = 2, nrow = 1,
          widths = c(3, 3),
          font.label = list(size = 22),
          align = "hv",
          labels = "AUTO")

ggarrange(plot1, plotB, plotD, plotE, ncol = 1, nrow = 4,
          font.label = list(size = 22),
          align = "hv",
          labels = c("", "C", "D", "E" ))

ggsave("~/Fig3.pdf", width=9, height=14)


