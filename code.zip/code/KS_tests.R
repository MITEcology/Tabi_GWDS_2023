rm(list=ls())
dev.off()

# load data
df0 <- read.csv("~/all_data.csv")  

# filter for RLS data 
df <- df0 %>% filter(program=="RLS")

# add year and ID
df$year <-  as.numeric(format(as.Date(df$survey_date), format = "%Y"))
df$ID <- paste(df$site_code, "_", df$year, sep="")

# remove biomass NAs
df1 <- df %>% filter(!is.na(biomass))

# add sampling effort
se <- df1 %>% dplyr::select(ID, survey_date) %>% group_by(ID) %>% unique %>% count()  
se$sampling_effort <- se$n
se$n <- NULL
df2 <- merge(df1, se, by=c("ID"), all.x=T )

# add SR 
sr <- df2 %>% dplyr::select(ID, species_name) %>% group_by(ID) %>% unique() %>% count()
df3 <- merge(df2, sr, by="ID", all.x = T)
df3$SR <- df3$n
df3$n <- NULL

# add TA
total_abundance <- df3 %>% dplyr::select(ID, total) %>% group_by(ID) %>% summarise(TA=sum(total, na.rm=T))
df4 <- merge(df3, total_abundance, by="ID", all.x = T)

########################################################################################
# Abundance distribution

# comm > 4 & only se > 1
df5 <-  df4 %>% filter(SR>4 & sampling_effort>1)   
TA1 <- df5 %>% dplyr::select(ID, TA) %>% distinct()
SR1 <- df5 %>% dplyr::select(ID, SR) %>% distinct()
  
hist( log(TA1$TA), col="#005BBB", xlab = "log total abundance", 
     ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(TA1$TA), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

hist( log(SR1$SR), col="#005BBB", xlab = "log richness", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(SR1$SR), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

# comm > 4 & SE = 1 
df6 <-  df4 %>% filter(SR>4  & sampling_effort==1 )   
TA2 <- df6 %>% dplyr::select(ID, TA) %>% distinct()
SR2 <- df6 %>% dplyr::select(ID, SR) %>% distinct()

hist( log(TA2$TA), col="#005BBB", xlab = "log total abundance", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(TA2$TA), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

hist( log(SR2$SR), col="#005BBB", xlab = "log richness", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(SR2$SR), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

# comm > 4 & only SE > 2 
df7 <-  df4 %>% filter(SR>4 & sampling_effort > 2)   
TA3 <- df7 %>% dplyr::select(ID, TA) %>% distinct()
SR3 <- df7 %>% dplyr::select(ID, SR) %>% distinct()

hist( log(TA3$TA), col="#005BBB", xlab = "log total abundance", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(TA3$TA), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

# comm > 4 & all
df8 <-  df4 %>% filter(SR>4)   
TA4 <- df8 %>% dplyr::select(ID, TA) %>% distinct()
SR4 <- df8 %>% dplyr::select(ID, SR) %>% distinct()

hist( log(TA4$TA), col="#005BBB", xlab = "log total abundance", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(TA4$TA), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

# comm > 4 & only se > 3
df9 <-  df4 %>% filter(SR>4 & sampling_effort > 3)   
TA5 <- df9 %>% dplyr::select(ID, TA) %>% distinct()
SR5 <- df9 %>% dplyr::select(ID, SR) %>% distinct()

hist( log(TA5$TA), col="#005BBB", xlab = "log total abundance", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(TA5$TA), na.rm=T), col="#FFD500", lty=2, lwd=1.5)

# comm > 4 & only se > 4
df10 <-  df4 %>% filter(SR>4 & sampling_effort > 4)   
TA6 <- df10 %>% dplyr::select(ID, TA) %>% distinct()
SR6 <- df10 %>% dplyr::select(ID, SR) %>% distinct()

hist( log(TA6$TA), col="#005BBB", xlab = "log total abundance", 
      ylab = "# of communities", breaks=30, main=NA, border="cornflowerblue" )
abline(v=median(log(TA6$TA), na.rm=T), col="#FFD500", lty=2, lwd=1.5)


######## KS tests

# 1. Compare dist SE > 1 and SE == 1 
ks.test(TA1$TA, TA2$TA)  # not same distribution
ks.test(SR1$SR, SR2$SR)  # not same distribution 

# 2. Compare dist SE = 1 and all 
ks.test(TA2$TA, TA4$TA)  #  same distribution
ks.test(SR2$SR, SR4$SR)  #  same distribution

# 3. Compare dist SE > 1 and all 
ks.test(TA1$TA, TA4$TA)  # not same distribution
ks.test(SR1$SR, SR4$SR)  # not same distribution

# 4. Compare dist SE > 2 and all 
ks.test(TA3$TA, TA4$TA)  # not same distribution
ks.test(SR3$SR, SR4$SR)  # not same distribution

# 5. Compare dist SE > 1 and SE > 2 
ks.test(TA1$TA, TA3$TA)  # somewhat similar
ks.test(SR1$SR, SR3$SR)  # not same distribution

# 6. Compare dist SE > 2 and SE > 3 
ks.test(TA3$TA, TA5$TA)  # same distribution
ks.test(SR3$SR, SR5$SR)  # same distribution

# Compare dist SE > 3 and SE > 4 
ks.test(TA5$TA, TA6$TA)  # same distribution
ks.test(SR5$SR, SR6$SR)  # same distribution



