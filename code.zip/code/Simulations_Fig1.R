rm(list=ls())
dev.off()

library(tidyr)
library(reshape2)
library(dplyr)
library(ggplot2)
library(NetIndices)
library(trophic)
library(ggpubr)

# Function to simulate community structure with harvest ####################################

Sim_TE_harvest <- function(sp, sTE, frac){
  
        b <- 0.35
        C <- sp^(b-1)                           # connectance 
        FM <- trophic::niche(sp, C)             # feeding matrix 
        TL <- TrophInd(FM)[,1]                  # trophic levels
        E <- rnorm(sp, mean=0, sd=0.1)          # noise to BS
        PPMR <- exp(1) * TL^4.8              
        mean.M <- PPMR^(TL-1+E) 
        sd.M <- 0.1 * mean.M                    # sd of body sizes increases with the mean
        TE <- sTE * mean.M^(-0.07)              # transfer efficiency dependent on body size (Woodson et al 2018)

        # size-selective harvest 
        probs.M <- mean.M/sum(mean.M)              # prob of being fished based on size
        fished_sp <- which(mean.M %in% sample(mean.M, floor(sp*frac), prob=probs.M))  # sample larger species 
        remove <- runif(sp, 0.3, 1)
        
        harvest <- lapply(fished_sp, function(x) {
          dist <-  rnorm( 5000, mean = mean.M[[x]], sd = sd.M[[x]] )
          probs <- pnorm(dist, mean = mean.M[[x]], sd = sd.M[[x]])
          harvest.dist <- dist[-which(dist %in% sample(dist, floor(remove[[x]]*5000), prob=probs))]
          new.mean.M <- mean(harvest.dist)
          sd.new.M <- sd(harvest.dist)
          remove.bm <- (sum(dist)  - sum(harvest.dist)) / sum(dist) 
          return(data.frame(sp=x, mean.M=mean.M[[x]], new.mean.M=new.mean.M, remove.bm=remove.bm, remove.ab=remove[[x]]))
        })
        

        df0 <- suppressMessages({ melt(harvest) })
        df <- tidyr::spread(df0, variable, value)
        
        harvest.mean.M <-  mean.M   
        harvest.mean.M[fished_sp] <- df$new.mean.M

        if( any(TE>1) ) {
          return(NA)
        }else{
          
          ki <-  0.25 + log(TE) / log(PPMR)  # size spectra biomass scaling coefficient (Woodson et al 2018)

          B <- (mean.M)^ki                                         # biomass proportional to body size
          k <- summary(lm(log(B) ~ log(mean.M)))$coef[2,1]
          harvest.B <- B
          harvest.B[fished_sp] <- (1-df$remove.bm) * B[fished_sp]
          harvest.k <- summary(lm(log(harvest.B) ~ log(harvest.mean.M)))$coef[2,1]
          
          rho <- cor.test(mean.M, B, method="spearman", exact=F)$est    # community structure
          harvest.rho <- cor.test(harvest.mean.M, harvest.B, method="spearman", exact=F)$est    # community structure
          
          return(data.frame( sp=sp, rho=rho, harvest.rho=harvest.rho, 
                             sTE=sTE, meanTE=mean(TE), 
                             k=k, harvest.k=harvest.k,
                             PPMR=mean(PPMR), maxPPMR=max(PPMR),
                             maxTL=max(TL) ))
  }
  
}

# Simulate #################################################################################
sp <- 50                              # number of species
frac <- 0.5                           # fraction of species being fished
n <- 10^4                           # number of simulations (communities)
sTE <- round(runif(n, 0.05, 1), 1)    # scaling factor of transfer efficiency

# run the simulations ######################################################################

res.harvest <- lapply(1:n, function(x) Sim_TE_harvest(sp, sTE[x], frac ) )

# put database together ####################################################################
d <- data.frame(do.call( "rbind", res.harvest))
d <- na.omit(d)
d$te <-  round(d$meanTE,1)
dd <- melt(d, id=c( "sp", "sTE", "te", "meanTE", "PPMR", "maxPPMR", "rho", "harvest.rho", "maxTL", "minBS", "maxBS"))
unique(dd$variable)
dd$fact <- ifelse(dd$variable == "k", "Protected", "Harvested")
head(dd)
df <- dd %>% dplyr::filter(te > 0.1 & te < 0.7 )
te_string <- as_labeller(c( `0.1` = "TE[c] == 0.1", `0.2` = "TE[c] == 0.2", `0.3` = "TE[c] == 0.3",
                            `0.4` = "TE[c] == 0.4",  `0.5` = "TE[c] == 0.5", `0.6` = "TE[c] == 0.6"), 
                            default = label_parsed)

# Figure 1 #################################################################################

sim <- ggplot(df,  aes(x=factor(fact), y=value, fill=fact))+ 
  geom_violin( color="white"  ) +
  geom_boxplot( outlier.shape=1, width=0.1 )+
  facet_wrap(~te, nrow=1, labeller = te_string)+
  theme_bw()+  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  xlab(" ") + ylab(expression(paste("Structure (", k[c], ")")) )+
  scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=20),
        strip.text = element_text(size = 20), 
        strip.background = element_rect(fill="white", color="white"))
sim

mean.M <- 8 * 10^5
sd.M <- mean.M * 0.1
remove <- 0.75
dist <-  rnorm( 5000, mean = mean.M, sd = sd.M )
probs <- pnorm(dist, mean = mean.M, sd = sd.M)
harvest.dist <- dist[-which(dist %in% sample(dist, floor(remove*5000), prob=probs))]

d1 <- data.frame(bs=dist, treat="Protected")
d2 <- data.frame(bs=harvest.dist, treat="Harvested")

dist_plot <- ggplot()+ 
  geom_histogram(data=d1, aes(x=log10(bs), fill=treat), color="white", alpha=0.6)+
  geom_histogram(data=d2, aes(x=log10(bs), fill=treat), color="white", alpha=0.9)+
  scale_fill_manual(values = c("#FFD500" ,"#005BBB"))+
  theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  ylab("Abundance")+
  xlab(bquote(log[10]~"(body size) distribution" )) +
  theme(legend.title=element_blank(), legend.position=c(0.2, 0.8),
        legend.text = element_text(size=16),
        axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=20),
        strip.text = element_text(size = 20),
        strip.background = element_rect(fill="white", color="white"))

dist_plot

ppmr_plot <- ggplot(d)+ 
  geom_histogram(aes(x=log10(maxPPMR)), color="white", fill="grey30", alpha=0.6)+
  theme_bw()+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  ylab("# of communities")+
  xlab(bquote(log[10]~"("~PPMR[max]~") distribution" )) +
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=20),
        strip.text = element_text(size = 20),
        strip.background = element_rect(fill="white", color="white"))

ppmr_plot

plot1 <- ggarrange( ppmr_plot, dist_plot, ncol = 2, nrow = 1,
          font.label = list(size = 22),
          align = "hv",
          labels = "AUTO")

ggarrange(plot1, sim, ncol = 1, nrow = 2,
          font.label = list(size = 22),
          align = "hv",
          labels = c("", "C"))

ggsave("~/Fig1.png", width=16, height=8)

# Figure S2 ################################################################################
te_string <- as_labeller(c( `0.1` = "TE[c] == 0.1", `0.2` = "TE[c] == 0.2", `0.3` = "TE[c] == 0.3", 
                            `0.4` = "TE[c] == 0.4", `0.5` = "TE[c] == 0.5",`0.6` = "TE[c] == 0.6", 
                            `0.7` = "TE[c] == 0.7", `0.8` = "TE[c] == 0.8"), default = label_parsed)
pp <- as_labeller(c( `1` = "PPMR[c] == 10", `2` = " PPMR[c] == 10^2", `3` = "PPMR[c] == 10^3",
                     `4` = "PPMR[c] == 10^4"),  default = label_parsed)
dd$ppmr <- ifelse( round(dd$PPMR) < 100, 1, ifelse(round(dd$PPMR) < 1000, 2, ifelse(round(dd$PPMR) < 10^4, 3, 4)))

ggplot(dd %>% filter(te>0),  aes(x=factor(fact), y=value, fill=fact))+ 
  geom_violin( color="white"  ) +
  geom_boxplot(outlier.shape = NA, fill="white", width=0.1 )+
  facet_grid(te~ppmr,  labeller = labeller(te=te_string, ppmr=pp))+
  theme_bw()+  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  xlab(" ") + ylab(expression(paste("Structure (", k, ")")) )+
  scale_fill_manual(values=alpha(c("#FFD500","#005BBB"),0.4))+
  theme(legend.position = "none", axis.title = element_text(size=20),
        axis.text.x = element_text(size=20), axis.text.y = element_text(size=20),
        strip.text = element_text(size = 20), 
        strip.background = element_rect(fill="white", color="white"))

ggsave("~/FigS2.png", height = 18, width = 12)


