rm(list=ls())

source('pcalg.R')
load('~/data.RData') 
head(db)

############ load variables
r <- as.numeric(db$Reg_BS_BM_coef)
se <- as.numeric(db$sampling_effort)
tsa <- as.numeric(db$SumTSAfull)
hpd <- as.numeric(db$HumanPopDensity)
pro <- as.numeric(db$IUCN_Ia)
coral <- as.numeric(db$Buffer10Km)

########### cut-off for sampling effort
t <- 1
########## transform continuous to binary variables using median
########## and filter by sampling effort

br <- r[se>t]
br[r[se>t]>median(r[se>t],na.rm=T)] <- 1
br[r[se>t]<=median(r[se>t],na.rm=T)] <- 0

bhpd <- hpd[se>t]
bhpd[hpd[se>t]>median(hpd[se>t],na.rm=T)] <- 1
bhpd[hpd[se>t]<=median(hpd[se>t],na.rm=T)] <- 0

btsa <- tsa[se>t]
btsa[tsa[se>t]>median(tsa[se>t],na.rm=T)] <- 1
btsa[tsa[se>t]<=median(tsa[se>t],na.rm=T)] <- 0

bcoral <- coral[se>t]
bcoral[coral[se>t]>median(coral[se>t],na.rm=T)] <- 1
bcoral[coral[se>t]<=median(coral[se>t],na.rm=T)] <- 0

bpro <- pro[se>t]

dat0 <- as.matrix(data.frame(bhpd,br,bpro,bcoral,btsa))
dat <- na.omit(dat0)
head(dat)

# Testing genuine effect between X=MPA and Y=structure (dep low indp high)

# i: X=Protection and Y=Structure are dependent
gSquareBin(3,2,c(1,4,5),dat)  

# iia: Z=Human and X=Protection are dependent
gSquareBin(3,1,c(5,4,2),dat) 

# iia.1: W=TSA and Z=Human are independent
gSquareBin(5,1,c(),dat) 
# iia.1: X=Protection and W=TSA are dependent
gSquareBin(3,5,c(),dat)  

# iia.2: Z=Human and W=Coral are independent
gSquareBin(1,4,c(),dat) 
# iia.2: X=Protection and W=Coral are dependent
gSquareBin(3,4,c(),dat) 

# iiia: Z=Human and Y=Structure are dependent
gSquareBin(1,2,c(4,5),dat) 
# iiia: Z=Human and Y=Structure are independent
gSquareBin(1,2,c(4,5,3),dat) 

# iib: Z=TSA and X=Protection are dependent
gSquareBin(5,3,c(4,1,2),dat) 

# iib.1: Z=TSA and W=Human are independent
gSquareBin(5,1,c(),dat) 
# iib.1: X=Protection and W=Human are dependent
gSquareBin(3,1,c(),dat) 

# iib.2: Z=TSA and W=Coral are independent
gSquareBin(5,4,c(),dat) 
# iib.2: X=Protection and W=Coral are dependent
gSquareBin(3,4,c(),dat) 

# iiib: Z=TSA and Y=Structure are dependent
gSquareBin(5,2,c(4,1),dat) 
# iiib: Z=TSA and Y=Structure are independent
gSquareBin(5,2,c(4,1,3),dat) 

# iic: Z=Coral and X=Protection are dependent
gSquareBin(4,3,c(5,1,2),dat) 

# iic.1: Z=Coral and W=Human are independent
gSquareBin(4,1,c(),dat) 
# iic.1: X=Protection and W=Human are dependent
gSquareBin(3,1,c(),dat) 

# iic.2: Z=Coral and W=TSA are independent
gSquareBin(4,5,c(),dat) 
# iic.2:X=Protection and W=Coral are dependent
gSquareBin(4,3,c(),dat) 

# iiic: Z=Coral and Y=Structure are dependent
gSquareBin(4,2,c(5,1),dat) 
# iiic: Z=Coral and Y=Structure are independent
gSquareBin(4,2,c(5,1,3),dat) 


# Direct effect of MPA on structure
d1 <- mean(br[bpro==1],na.rm = T)
d2 <- mean(br[bpro==0],na.rm = T)
if (is.na(d1)) {d1 <- 0}
if (is.na(d2)) {d2 <- 0}
d <- d1 - d2
print(d) 

